import { redirect } from 'next/navigation';

export default function PortalRedirectPage() {
  redirect('/portal-kpr');
}
